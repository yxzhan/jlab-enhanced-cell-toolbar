"use strict";
(self["webpackChunk_jlab_enhanced_cell_toolbar"] = self["webpackChunk_jlab_enhanced_cell_toolbar"] || []).push([["lib_index_js"],{

/***/ "./lib/attachmentseditor.js":
/*!**********************************!*\
  !*** ./lib/attachmentseditor.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttachmentsEditor": () => (/* binding */ AttachmentsEditor),
/* harmony export */   "AttachmentsTool": () => (/* binding */ AttachmentsTool)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/translation */ "webpack/sharing/consume/default/@jupyterlab/translation");
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_translation__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_3__);




class AttachmentsEditor extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_3__.Widget {
    constructor(model = null, translator) {
        super();
        this.addClass('jp-cell-enh-attachment-editor');
        this._model = null;
        this.trans = (translator !== null && translator !== void 0 ? translator : _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_1__.nullTranslator).load('cell-toolbar');
        this.info = document.createElement('p');
        this.table = document.createElement('table');
        this.node.insertAdjacentElement('beforeend', this.table);
        this.node.insertAdjacentElement('beforeend', this.info);
        // Initialize with the model
        this.model = model;
    }
    /**
     * Attachment model handle by this widget
     */
    get model() {
        return this._model;
    }
    set model(v) {
        if (this._model !== v) {
            if (this._model) {
                this._model.changed.disconnect(this.onModelChanged, this);
            }
            this._model = v;
            if (this._model) {
                this._model.changed.connect(this.onModelChanged, this);
            }
            this._refresh();
        }
    }
    _refresh() {
        var _a;
        this._clearListeners();
        this.info.innerText = '';
        this.table.innerHTML = `<caption>${this.trans.__('Attachments')}</caption>`;
        if (this._model !== null) {
            if (this._model.length > 0) {
                const attachments = this._model.keys.map(k => {
                    var _a, _b;
                    const types = Object.keys((_b = (_a = this._model.get(k)) === null || _a === void 0 ? void 0 : _a.data) !== null && _b !== void 0 ? _b : {});
                    return `<tr data-attachment-key="${k}"><td>${k}</td><td>${types.join(';')}</td><td><button title="${this.trans.__('Delete')}"></button></td></tr>`;
                });
                (_a = this.node
                    .querySelector('table')) === null || _a === void 0 ? void 0 : _a.insertAdjacentHTML('beforeend', attachments.join(''));
                this.node.querySelectorAll('button').forEach(button => {
                    _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.deleteIcon.element({ container: button });
                });
                this._addListeners();
            }
            else {
                this.info.innerText = this.trans.__('There are no attachments for this cell.');
            }
        }
    }
    handleEvent(event) {
        var _a, _b, _c;
        switch (event.type) {
            case 'click':
                {
                    event.preventDefault();
                    const k = (_b = (_a = event.currentTarget.parentElement) === null || _a === void 0 ? void 0 : _a.parentElement) === null || _b === void 0 ? void 0 : _b.getAttribute('data-attachment-key');
                    if (k) {
                        (_c = this._model) === null || _c === void 0 ? void 0 : _c.remove(k);
                    }
                }
                break;
        }
    }
    onAfterAttach(msg) {
        super.onAfterAttach(msg);
        this._addListeners();
    }
    onBeforeDetach(msg) {
        this._clearListeners();
        super.onBeforeDetach(msg);
    }
    onModelChanged() {
        this._refresh();
    }
    _addListeners() {
        this.table.querySelectorAll('button').forEach(button => {
            button.addEventListener('click', this);
        });
    }
    _clearListeners() {
        this.table.querySelectorAll('button').forEach(button => {
            button.removeEventListener('click', this);
        });
    }
}
/**
 * Attachments editor as notebook tool
 */
class AttachmentsTool extends _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookTools.Tool {
    constructor(translator) {
        super();
        this._editor = new AttachmentsEditor(null, translator);
        const layout = (this.layout = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_3__.PanelLayout());
        layout.addWidget(this._editor);
    }
    /**
     * Handle a change to the active cell.
     *
     * #### Notes
     * The default implementation is a no-op.
     */
    onActiveCellChanged(msg) {
        if (this.notebookTools.activeCell &&
            ['markdown', 'raw'].includes(this.notebookTools.activeCell.model.type)) {
            this._editor.model = this.notebookTools.activeCell
                .model.attachments;
        }
        else {
            this._editor.model = null;
        }
    }
}


/***/ }),

/***/ "./lib/attributeeditor.js":
/*!********************************!*\
  !*** ./lib/attributeeditor.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttributeEditor": () => (/* binding */ AttributeEditor)
/* harmony export */ });
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Editor for a single cell metadata attribute
 */
class AttributeEditor extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.Widget {
    constructor(options) {
        const { metadata, keys, label, values, noValue, editable, placeholder } = Object.assign({ editable: false }, options);
        const allValues = noValue !== undefined ? [[noValue, noValue]].concat(values) : values;
        const node = document.createElement('div');
        const optionsList = allValues.map(v => `<option value="${editable ? v[1] : v[0]}">${v[1]}</option>`);
        if (editable) {
            const uuid = Private.getDataListUID();
            node.insertAdjacentHTML('afterbegin', `<label>${label}
      <input list="${uuid}" />
      <datalist id="${uuid}">${optionsList.join('')}</datalist>
    </label>`);
        }
        else {
            node.insertAdjacentHTML('afterbegin', `<label>${label}
      <select>${optionsList.join('')}</select>
    </label>`);
        }
        super({ node });
        this.addClass('jp-enh-attribute-editor');
        this.metadata = metadata;
        this.keys = keys;
        this.noValue = noValue;
        this.editable = editable;
        this.values = allValues;
        this.selectNode = node.querySelector(editable ? 'input' : 'select');
        if (editable && placeholder) {
            this.selectNode.placeholder = placeholder;
        }
        // Break at first found key
        for (const key of this.keys) {
            if (this._getValue(key) !== undefined) {
                this.onMetadataChanged(this.metadata, {
                    key,
                    newValue: this.metadata.get(key),
                    oldValue: undefined,
                    type: 'add'
                });
                break;
            }
        }
        this.metadata.changed.connect(this.onMetadataChanged, this);
    }
    /**
     * Dispose widget resources
     */
    dispose() {
        if (this.isDisposed) {
            return;
        }
        this.metadata.changed.disconnect(this.onMetadataChanged, this);
        super.dispose();
    }
    /**
     * Handle event on the element
     * @param event Event
     */
    handleEvent(event) {
        var _a, _b;
        switch (event.type) {
            case 'change':
                {
                    const inputValue = event.target.value;
                    const newValue = inputValue === this.noValue
                        ? null
                        : this.editable
                            ? (_b = ((_a = this.values.find(([value, label]) => inputValue === label)) !== null && _a !== void 0 ? _a : [])[0]) !== null && _b !== void 0 ? _b : inputValue : inputValue;
                    for (const k of this.keys) {
                        const keyPath = k.split('/');
                        if (keyPath.length > 1) {
                            let value = this.metadata.get(keyPath[0]);
                            if (value === undefined) {
                                value = {};
                                this.metadata.set(keyPath[0], value);
                            }
                            const topValue = value;
                            for (let p = 1; p < keyPath.length - 1; p++) {
                                if (value[keyPath[p]] === undefined) {
                                    value[keyPath[p]] = {};
                                }
                                value = value[keyPath[p]];
                            }
                            if (newValue === null) {
                                delete value[keyPath[keyPath.length - 1]];
                            }
                            else {
                                value[keyPath[keyPath.length - 1]] = newValue;
                            }
                            this.metadata.set(keyPath[0], topValue);
                        }
                        else {
                            if (newValue === null) {
                                this.metadata.delete(keyPath[0]);
                            }
                            else {
                                this.metadata.set(keyPath[0], newValue);
                            }
                        }
                    }
                }
                break;
            case 'focusin':
                if (this.editable) {
                    this.selectNode.value = '';
                }
                break;
            case 'focusout':
                if (this.editable) {
                    for (const key of this.keys) {
                        if (this._getValue(key) !== undefined) {
                            this.onMetadataChanged(this.metadata, {
                                key,
                                newValue: this.metadata.get(key),
                                oldValue: undefined,
                                type: 'change'
                            });
                            break;
                        }
                    }
                }
                break;
        }
    }
    onAfterAttach(msg) {
        super.onAfterAttach(msg);
        this.selectNode.addEventListener('change', this);
        if (this.editable) {
            this.selectNode.addEventListener('focusin', this);
            this.selectNode.addEventListener('focusout', this);
        }
    }
    onBeforeDetach(msg) {
        this.selectNode.removeEventListener('change', this);
        if (this.editable) {
            this.selectNode.removeEventListener('focusin', this);
            this.selectNode.removeEventListener('focusout', this);
        }
        super.onBeforeDetach(msg);
    }
    onMetadataChanged(metadata, changes) {
        var _a, _b;
        if (this.keys.includes(changes.key)) {
            const value = this._getValue(changes.key);
            if (value === undefined) {
                this.selectNode.value = this.noValue ? this.noValue : '';
            }
            else {
                this.selectNode.value = this.editable
                    ? (_b = ((_a = this.values.find(([v, label]) => value === v)) !== null && _a !== void 0 ? _a : [])[1]) !== null && _b !== void 0 ? _b : value : value;
            }
        }
    }
    _getValue(key) {
        const keyPath = key.split('/');
        let value = this.metadata.get(keyPath[0]);
        for (let p = 1; p < keyPath.length; p++) {
            value = (value !== null && value !== void 0 ? value : {})[keyPath[p]];
        }
        return value;
    }
}
var Private;
(function (Private) {
    let counter = 0;
    function getDataListUID() {
        return `attribute-widget-${counter++}`;
    }
    Private.getDataListUID = getDataListUID;
})(Private || (Private = {}));


/***/ }),

/***/ "./lib/celltoolbartracker.js":
/*!***********************************!*\
  !*** ./lib/celltoolbartracker.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CellBarExtension": () => (/* binding */ CellBarExtension),
/* harmony export */   "CellToolbarTracker": () => (/* binding */ CellToolbarTracker),
/* harmony export */   "DEFAULT_TOOLBAR": () => (/* binding */ DEFAULT_TOOLBAR)
/* harmony export */ });
/* harmony import */ var _jupyterlab_observables__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/observables */ "webpack/sharing/consume/default/@jupyterlab/observables");
/* harmony import */ var _jupyterlab_observables__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_observables__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/algorithm */ "webpack/sharing/consume/default/@lumino/algorithm");
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @lumino/coreutils */ "webpack/sharing/consume/default/@lumino/coreutils");
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_lumino_coreutils__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _celltoolbarwidget__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./celltoolbarwidget */ "./lib/celltoolbarwidget.js");
/* harmony import */ var _positionedbutton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./positionedbutton */ "./lib/positionedbutton.js");
/* harmony import */ var _tokens__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tokens */ "./lib/tokens.js");
var __rest = (undefined && undefined.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};








const DEFAULT_HELPER_BUTTONS = [
    // Originate from @jupyterlab/notebook-extension
    {
        command: 'notebook:run-cell-and-select-next',
        icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.runIcon
    },
    {
        command: 'notebook:move-cell-up',
        icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.caretUpEmptyThinIcon
    },
    {
        command: 'notebook:move-cell-down',
        icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.caretDownEmptyThinIcon
    },
    {
        command: 'notebook:insert-cell-below',
        icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.addIcon
    }
];
/**
 * Default toolbar definition
 */
const DEFAULT_TOOLBAR = [
    {
        name: 'markdown-to-code',
        cellType: 'markdown',
        command: 'notebook:change-cell-to-code',
        icon: 'ui-components:code'
    },
    {
        name: 'code-to-markdown',
        cellType: 'code',
        command: 'notebook:change-cell-to-markdown',
        icon: 'ui-components:markdown'
    },
    // Not available by default
    // {
    //   name: 'format-code',
    //   cellType: 'code',
    //   command: 'jupyterlab_code_formatter:format',
    //   icon: '@jlab-enhanced/cell-toolbar:format',
    //   tooltip: 'Format Cell'
    // },
    {
        name: 'delete-cell',
        command: 'notebook:delete-cell',
        icon: 'ui-components:delete'
    },
    {
        name: 'spacer',
        type: 'spacer'
    }
];
/**
 * Widget cell toolbar class
 */
const CELL_BAR_CLASS = 'jp-enh-cell-bar';
/**
 * Watch a notebook, and each time a cell is created add a CellTagsWidget to it.
 */
class CellToolbarTracker {
    constructor(panel, commands, cellToolbarFactory, toolbarRegistry, configuration = {
        defaultTags: [],
        floatPosition: null,
        helperButtons: [
            'insert-cell-below',
            'move-cell-down',
            'move-cell-up',
            'run-cell-and-select-next'
        ],
        leftSpace: 0,
        cellType: {}
    }) {
        this.panel = panel;
        this.commands = commands;
        this.cellToolbarFactory = cellToolbarFactory;
        this.toolbarRegistry = toolbarRegistry;
        this._allTags = new _jupyterlab_observables__WEBPACK_IMPORTED_MODULE_0__.ObservableList();
        this._isActive = true;
        this._isDisposed = false;
        this._previousDefaultTags = new Array();
        this._disposed = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_4__.Signal(this);
        this._config = _lumino_coreutils__WEBPACK_IMPORTED_MODULE_3__.JSONExt.deepCopy(configuration);
        this._viewConfig = {};
        const k = Object.keys(this._config.cellType);
        for (const item of Object.values(_tokens__WEBPACK_IMPORTED_MODULE_5__.CellToolbar.ViewItems)) {
            this._viewConfig[item] = k.includes(item);
        }
        // // Add lock tag button
        // this._unlockTagsButton = new ToggleButton({
        //   className: (): string => 'jp-enh-cell-nb-button',
        //   enabled: (): boolean =>
        //     (!this.panel?.context.model.readOnly &&
        //       this.panel?.context.contentsModel?.writable) ??
        //     false,
        //   icon: (state: boolean): LabIcon =>
        //     state ? lockedTagsIcon : unlockedTagsIcon,
        //   tooltip: (state: boolean): string =>
        //     state ? 'Lock tags' : 'Unlock tags',
        //   onClick: (state: boolean): void => {
        //     for (const id in this._tagsModels) {
        //       this._tagsModels[id].unlockedTags = state;
        //     }
        //   }
        // });
        // let insertionPoint = -1;
        // find(panel.toolbar.children(), (tbb, index) => {
        //   insertionPoint = index; // It will be the last index or the cell type input
        //   return tbb.hasClass('jp-Notebook-toolbarCellType');
        // });
        // panel.toolbar.insertItem(
        //   insertionPoint + 1,
        //   'edit-tags',
        //   this._unlockTagsButton
        // );
        // Initialize styling
        this.isActive = true;
        const cells = this.panel.context.model.cells;
        cells.changed.connect(this.updateConnectedCells, this);
        // panel.context.fileChanged.connect(this._onFileChanged, this);
    }
    /**
     * Cell toolbar configuration
     */
    get configuration() {
        return _lumino_coreutils__WEBPACK_IMPORTED_MODULE_3__.JSONExt.deepCopy(this._config);
    }
    set configuration(v) {
        if (!_lumino_coreutils__WEBPACK_IMPORTED_MODULE_3__.JSONExt.deepEqual(v, this._config)) {
            this._config = Object.assign(Object.assign({}, this._config), _lumino_coreutils__WEBPACK_IMPORTED_MODULE_3__.JSONExt.deepCopy(v));
            const items = Object.keys(this._config.cellType);
            for (const value of Object.values(_tokens__WEBPACK_IMPORTED_MODULE_5__.CellToolbar.ViewItems)) {
                if (items.includes(value)) {
                    this.setViewState(value, true);
                }
            }
            this._onConfigChanged();
        }
    }
    /**
     * A signal emitted when the poll is disposed.
     */
    get disposed() {
        return this._disposed;
    }
    /**
     * Whether the toolbars should be displayed or not.
     */
    get isActive() {
        return this._isActive;
    }
    set isActive(v) {
        if (this._isActive !== v) {
            this._isActive = v;
            const cells = this.panel.context.model.cells;
            if (cells) {
                if (this._isActive) {
                    (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__.each)(cells.iter(), model => this._addToolbar(model));
                }
                else {
                    (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__.each)(cells.iter(), model => this._removeToolbar(model));
                }
            }
        }
        this.panel.content.node.setAttribute('data-jp-enh-cell-toolbar', `${v}`);
    }
    /**
     * Test whether the context is disposed.
     */
    get isDisposed() {
        return this._isDisposed;
    }
    /**
     * Dispose of the resources held by the object.
     */
    dispose() {
        var _a;
        if (this.isDisposed) {
            return;
        }
        this._isDisposed = true;
        const cells = (_a = this.panel) === null || _a === void 0 ? void 0 : _a.context.model.cells;
        if (cells) {
            cells.changed.disconnect(this.updateConnectedCells, this);
            (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__.each)(cells.iter(), model => this._removeToolbar(model));
        }
        // this.panel?.context.fileChanged.disconnect(this._onFileChanged);
        this._disposed.emit();
        _lumino_signaling__WEBPACK_IMPORTED_MODULE_4__.Signal.clearData(this);
    }
    getViewState(state) {
        var _a;
        return (_a = this._viewConfig[state]) !== null && _a !== void 0 ? _a : true;
    }
    setViewState(state, v) {
        if (this._viewConfig[state] === undefined) {
            // Bail early
            console.warn(`Try to set unknown state '${state}'`);
            return;
        }
        if (this._viewConfig[state] !== v) {
            this._viewConfig[state] = v;
            this._onConfigChanged();
        }
    }
    /**
     * Callback to react to cells list changes
     *
     * @param cells List of notebook cells
     * @param changed Modification of the list
     */
    updateConnectedCells(cells, changed) {
        if (this.isActive) {
            changed.oldValues.forEach(model => this._removeToolbar(model));
            changed.newValues.forEach(model => this._addToolbar(model));
        }
    }
    _addToolbar(model) {
        const cell = this._getCell(model);
        if (cell) {
            const { helperButtons, leftSpace, floatPosition } = this._config;
            // const tagsModel = (this._tagsModels[model.id] = new TagsModel(
            //   model,
            //   this._allTags
            //   // this._unlockTagsButton.toggled
            // ));
            const toolbar = new _celltoolbarwidget__WEBPACK_IMPORTED_MODULE_6__.CellToolbar(leftSpace !== null && leftSpace !== void 0 ? leftSpace : 0, floatPosition);
            this._setToolbar(cell, toolbar);
            toolbar.addClass(CELL_BAR_CLASS);
            cell.layout.insertWidget(0, toolbar);
            DEFAULT_HELPER_BUTTONS.filter(entry => helperButtons.includes(entry.command.split(':')[1]) &&
                (entry.cellType === undefined || entry.cellType === cell.model.type)).forEach(entry => {
                if (this.commands.hasCommand(entry.command)) {
                    const { command, tooltip } = entry, others = __rest(entry, ["command", "tooltip"]);
                    const shortName = command.split(':')[1];
                    const button = new _positionedbutton__WEBPACK_IMPORTED_MODULE_7__.PositionedButton(Object.assign(Object.assign({}, others), { callback: () => {
                            this.commands.execute(command);
                        }, className: shortName && `jp-enh-cell-${shortName}`, tooltip: tooltip || this.commands.label(entry.command) }));
                    button.addClass(CELL_BAR_CLASS);
                    cell.layout.addWidget(button);
                }
            });
        }
    }
    _getCell(model) {
        var _a;
        return (_a = this.panel) === null || _a === void 0 ? void 0 : _a.content.widgets.find(widget => widget.model === model);
    }
    _findToolbarWidgets(cell) {
        const widgets = cell.layout.widgets;
        // Search for header using the CSS class or use the first one if not found.
        return widgets.filter(widget => widget.hasClass(CELL_BAR_CLASS)) || [];
    }
    _removeToolbar(model) {
        const cell = this._getCell(model);
        if (cell) {
            this._findToolbarWidgets(cell).forEach(widget => widget.dispose());
        }
    }
    /**
     * Set the toolbar items of a cell
     */
    _setToolbar(cell, toolbar) {
        const cellType = cell.model.type;
        const items = this.cellToolbarFactory(cell);
        if (Array.isArray(items)) {
            items
                .filter(({ name }) => {
                const itemType = this.configuration.cellType[name];
                return (this.getViewState(name) &&
                    (typeof itemType !== 'string' || itemType === cellType));
            })
                .forEach(({ name, widget }) => {
                toolbar.addItem(name, widget);
            });
        }
        else {
            const updateToolbar = (list, changes) => {
                switch (changes.type) {
                    case 'add':
                        changes.newValues.forEach((item, index) => {
                            const itemType = this.configuration.cellType[item.name];
                            if (this.getViewState(item.name) === false ||
                                (itemType && itemType !== cellType)) {
                                item.widget.hide();
                            }
                            else if (item.name === _tokens__WEBPACK_IMPORTED_MODULE_5__.CellToolbar.ViewItems.TAGS) {
                                item.widget.model.tags = this._allTags;
                            }
                            toolbar.insertItem(changes.newIndex + index, item.name, item.widget);
                        });
                        break;
                    case 'move':
                        changes.oldValues.forEach(item => {
                            item.widget.parent = null;
                        });
                        changes.newValues.forEach((item, index) => {
                            toolbar.insertItem(changes.newIndex + index, item.name, item.widget);
                        });
                        break;
                    case 'remove':
                        changes.oldValues.forEach(item => {
                            item.widget.parent = null;
                        });
                        break;
                    case 'set':
                        changes.oldValues.forEach(item => {
                            item.widget.parent = null;
                        });
                        changes.newValues.forEach((item, index) => {
                            const existingIndex = (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__.findIndex)(toolbar.names(), name => item.name === name);
                            if (existingIndex >= 0) {
                                (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__.toArray)(toolbar.children())[existingIndex].parent = null;
                            }
                            const itemType = this.configuration.cellType[item.name];
                            if (itemType && itemType !== cellType) {
                                item.widget.hide();
                            }
                            else if (item.name === _tokens__WEBPACK_IMPORTED_MODULE_5__.CellToolbar.ViewItems.TAGS) {
                                item.widget.model.tags = this._allTags;
                            }
                            toolbar.insertItem(changes.newIndex + index, item.name, item.widget);
                        });
                        break;
                }
            };
            updateToolbar(items, {
                newIndex: 0,
                newValues: (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__.toArray)(items),
                oldIndex: 0,
                oldValues: [],
                type: 'add'
            });
            items.changed.connect(updateToolbar);
            cell.disposed.connect(() => {
                items.changed.disconnect(updateToolbar);
            });
        }
        const currentItems = (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__.toArray)(toolbar.names());
        for (const state in this._viewConfig) {
            if (this._viewConfig[state] && !currentItems.includes(state)) {
                toolbar.addItem(state, this.toolbarRegistry.createWidget(_tokens__WEBPACK_IMPORTED_MODULE_5__.FACTORY_NAME, cell, { name: state }));
            }
        }
    }
    /**
     * Callback on file changed
     */
    // private _onFileChanged(): void {
    //   this._unlockTagsButton.update();
    // }
    /**
     * Call back on configuration changes
     */
    _onConfigChanged() {
        var _a, _b, _c;
        if (!this.isActive) {
            // Bail early
            return;
        }
        // Reset toolbar when settings changes
        if ((_a = this.panel) === null || _a === void 0 ? void 0 : _a.context.model.cells) {
            (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_2__.each)((_b = this.panel) === null || _b === void 0 ? void 0 : _b.context.model.cells.iter(), model => {
                this._removeToolbar(model);
                this._addToolbar(model);
            });
        }
        // Update tags
        const newDefaultTags = (_c = this._config.defaultTags) !== null && _c !== void 0 ? _c : [];
        // Update default tag in shared tag list
        const toAdd = newDefaultTags.filter(tag => !this._previousDefaultTags.includes(tag));
        if (toAdd.length > 0) {
            this._allTags.pushAll(toAdd);
        }
        this._previousDefaultTags
            .filter(tag => !newDefaultTags.includes(tag))
            .forEach(tag => this._allTags.removeValue(tag));
        this._previousDefaultTags = newDefaultTags;
    }
}
/**
 * Widget extension that creates a CellToolbarTracker each time a notebook is
 * created.
 */
class CellBarExtension {
    constructor(commands, cellToolbarFactory, toolbarRegistry, settings) {
        this.commands = commands;
        this.cellToolbarFactory = cellToolbarFactory;
        this.toolbarRegistry = toolbarRegistry;
        this.settings = settings;
        this._toolbarMap = new WeakMap();
    }
    createNew(panel) {
        var _a;
        const toolbarTracker = new CellToolbarTracker(panel, this.commands, this.cellToolbarFactory, this.toolbarRegistry);
        this._toolbarMap.set(panel, toolbarTracker);
        if (this.settings) {
            const onSettingsChanged = (settings) => {
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                const _a = settings.composite, { toolbar } = _a, config = __rest(_a, ["toolbar"]);
                const cellType = {};
                toolbar
                    .filter(item => !item.disabled)
                    .forEach(item => {
                    var _a;
                    cellType[item.name] = (_a = item.cellType) !== null && _a !== void 0 ? _a : null;
                });
                toolbarTracker.configuration = Object.assign(Object.assign({}, config), { cellType });
            };
            onSettingsChanged(this.settings);
            toolbarTracker.disposed.connect(() => {
                var _a;
                (_a = this.settings) === null || _a === void 0 ? void 0 : _a.changed.disconnect(onSettingsChanged);
            });
            (_a = this.settings) === null || _a === void 0 ? void 0 : _a.changed.connect(onSettingsChanged);
        }
        else {
            const cellType = {};
            DEFAULT_TOOLBAR.forEach(item => {
                var _a;
                cellType[item.name] = (_a = item.cellType) !== null && _a !== void 0 ? _a : null;
            });
            toolbarTracker.configuration = Object.assign(Object.assign({}, toolbarTracker.configuration), { cellType });
        }
        return toolbarTracker;
    }
    /**
     * Get the cell toolbars handler for a notebook
     *
     * @param panel Notebook
     * @returns The cell toolbars handler
     */
    getToolbarsHandler(panel) {
        return this._toolbarMap.get(panel);
    }
}


/***/ }),

/***/ "./lib/celltoolbarwidget.js":
/*!**********************************!*\
  !*** ./lib/celltoolbarwidget.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CellToolbar": () => (/* binding */ CellToolbar)
/* harmony export */ });
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/algorithm */ "webpack/sharing/consume/default/@lumino/algorithm");
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_algorithm__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_properties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/properties */ "webpack/sharing/consume/default/@lumino/properties");
/* harmony import */ var _lumino_properties__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_properties__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./utils */ "./lib/utils.js");




/**
 * Cell Toolbar Widget
 */
class CellToolbar extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.Widget {
    constructor(leftSpace = 0, position = null) {
        super();
        this.layout = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.PanelLayout();
        this.addClass('jp-enh-cell-toolbar');
        // Set style
        this.node.style.position = 'absolute';
        if (position) {
            this.node.style.right = `${position.right}px`;
            this.node.style.top = `${position.top}px`;
            this.node.style.justifyContent = 'flex-end';
            this.node.style.width = 'max-content';
            // Set a background if the toolbar overlaps the border
            if (position.top < 22) {
                this.addClass('jp-overlap');
            }
        }
        else {
            this.node.style.left = `${leftSpace}px`;
            this.node.style.top = '0px';
            this.node.style.width = `calc( 100% - ${leftSpace}px - ${(0,_utils__WEBPACK_IMPORTED_MODULE_3__.getCSSVar)('--jp-cell-collapser-width')} - ${(0,_utils__WEBPACK_IMPORTED_MODULE_3__.getCSSVar)('--jp-cell-prompt-width')} - 2 * ${(0,_utils__WEBPACK_IMPORTED_MODULE_3__.getCSSVar)('--jp-cell-padding')} )`;
        }
    }
    /**
     * Get an iterator over the ordered toolbar item names.
     *
     * @returns An iterator over the toolbar item names.
     */
    names() {
        const layout = this.layout;
        return (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_0__.map)(layout.widgets, widget => {
            return Private.nameProperty.get(widget);
        });
    }
    /**
     * Add an item to the end of the toolbar.
     *
     * @param name - The name of the widget to add to the toolbar.
     *
     * @param widget - The widget to add to the toolbar.
     *
     * @param index - The optional name of the item to insert after.
     *
     * @returns Whether the item was added to toolbar.  Returns false if
     *   an item of the same name is already in the toolbar.
     *
     * #### Notes
     * The item can be removed from the toolbar by setting its parent to `null`.
     */
    addItem(name, widget) {
        const layout = this.layout;
        return this.insertItem(layout.widgets.length, name, widget);
    }
    /**
     * Insert an item into the toolbar at the specified index.
     *
     * @param index - The index at which to insert the item.
     *
     * @param name - The name of the item.
     *
     * @param widget - The widget to add.
     *
     * @returns Whether the item was added to the toolbar. Returns false if
     *   an item of the same name is already in the toolbar.
     *
     * #### Notes
     * The index will be clamped to the bounds of the items.
     * The item can be removed from the toolbar by setting its parent to `null`.
     */
    insertItem(index, name, widget) {
        const existing = (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_0__.find)(this.names(), value => value === name);
        if (existing) {
            return false;
        }
        const layout = this.layout;
        const j = Math.max(0, Math.min(index, layout.widgets.length));
        layout.insertWidget(j, widget);
        Private.nameProperty.set(widget, name);
        return true;
    }
    /**
     * Insert an item into the toolbar at the after a target item.
     *
     * @param at - The target item to insert after.
     *
     * @param name - The name of the item.
     *
     * @param widget - The widget to add.
     *
     * @returns Whether the item was added to the toolbar. Returns false if
     *   an item of the same name is already in the toolbar.
     *
     * #### Notes
     * The index will be clamped to the bounds of the items.
     * The item can be removed from the toolbar by setting its parent to `null`.
     */
    insertAfter(at, name, widget) {
        return this._insertRelative(at, 1, name, widget);
    }
    /**
     * Insert an item into the toolbar at the before a target item.
     *
     * @param at - The target item to insert before.
     *
     * @param name - The name of the item.
     *
     * @param widget - The widget to add.
     *
     * @returns Whether the item was added to the toolbar. Returns false if
     *   an item of the same name is already in the toolbar.
     *
     * #### Notes
     * The index will be clamped to the bounds of the items.
     * The item can be removed from the toolbar by setting its parent to `null`.
     */
    insertBefore(at, name, widget) {
        return this._insertRelative(at, 0, name, widget);
    }
    _insertRelative(at, offset, name, widget) {
        const nameWithIndex = (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_0__.map)(this.names(), (name, i) => {
            return { name: name, index: i };
        });
        const target = (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_0__.find)(nameWithIndex, x => x.name === at);
        if (target) {
            return this.insertItem(target.index + offset, name, widget);
        }
        return false;
    }
    /**
     * Handle the DOM events for the widget.
     *
     * @param event - The DOM event sent to the widget.
     *
     * #### Notes
     * This method implements the DOM `EventListener` interface and is
     * called in response to events on the dock panel's node. It should
     * not be called directly by user code.
     */
    handleEvent(event) {
        switch (event.type) {
            case 'click':
                this.handleClick(event);
                break;
            default:
                break;
        }
    }
    /**
     * Handle a DOM click event.
     */
    handleClick(event) {
        // Stop propagating the click outside the toolbar
        event.stopPropagation();
        // Clicking a label focuses the corresponding control
        // that is linked with `for` attribute, so let it be.
        if (event.target instanceof HTMLLabelElement) {
            const forId = event.target.getAttribute('for');
            if (forId && this.node.querySelector(`#${forId}`)) {
                return;
            }
        }
        // If this click already focused a control, let it be.
        if (this.node.contains(document.activeElement)) {
            return;
        }
        // Otherwise, activate the parent widget, which may take focus if desired.
        if (this.parent) {
            this.parent.activate();
        }
    }
    /**
     * Handle `after-attach` messages for the widget.
     */
    onAfterAttach(msg) {
        this.node.addEventListener('click', this);
    }
    /**
     * Handle `before-detach` messages for the widget.
     */
    onBeforeDetach(msg) {
        this.node.removeEventListener('click', this);
    }
}
var Private;
(function (Private) {
    /**
     * An attached property for the name of a toolbar item.
     */
    Private.nameProperty = new _lumino_properties__WEBPACK_IMPORTED_MODULE_1__.AttachedProperty({
        name: 'name',
        create: () => ''
    });
})(Private || (Private = {}));


/***/ }),

/***/ "./lib/icon.js":
/*!*********************!*\
  !*** ./lib/icon.js ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "formatIcon": () => (/* binding */ formatIcon),
/* harmony export */   "lockedTagsIcon": () => (/* binding */ lockedTagsIcon),
/* harmony export */   "unlockedTagsIcon": () => (/* binding */ unlockedTagsIcon)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tokens__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tokens */ "./lib/tokens.js");
/* harmony import */ var _style_icons_format_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../style/icons/format.svg */ "./style/icons/format.svg");
/* harmony import */ var _style_icons_lockedtags_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../style/icons/lockedtags.svg */ "./style/icons/lockedtags.svg");
/* harmony import */ var _style_icons_unlockedtags_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../style/icons/unlockedtags.svg */ "./style/icons/unlockedtags.svg");


// icon svg import statements



const formatIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: `${_tokens__WEBPACK_IMPORTED_MODULE_1__.EXTENSION_ID}:format`,
    svgstr: _style_icons_format_svg__WEBPACK_IMPORTED_MODULE_2__["default"]
});
const lockedTagsIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: `${_tokens__WEBPACK_IMPORTED_MODULE_1__.EXTENSION_ID}:lockedtags`,
    svgstr: _style_icons_lockedtags_svg__WEBPACK_IMPORTED_MODULE_3__["default"]
});
const unlockedTagsIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: `${_tokens__WEBPACK_IMPORTED_MODULE_1__.EXTENSION_ID}:unlockedtags`,
    svgstr: _style_icons_unlockedtags_svg__WEBPACK_IMPORTED_MODULE_4__["default"]
});


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "formatIcon": () => (/* reexport safe */ _icon__WEBPACK_IMPORTED_MODULE_6__.formatIcon)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/codeeditor */ "webpack/sharing/consume/default/@jupyterlab/codeeditor");
/* harmony import */ var _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/translation */ "webpack/sharing/consume/default/@jupyterlab/translation");
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_translation__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _attachmentseditor__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./attachmentseditor */ "./lib/attachmentseditor.js");
/* harmony import */ var _attributeeditor__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./attributeeditor */ "./lib/attributeeditor.js");
/* harmony import */ var _celltoolbartracker__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./celltoolbartracker */ "./lib/celltoolbartracker.js");
/* harmony import */ var _metadataeditor__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./metadataeditor */ "./lib/metadataeditor.js");
/* harmony import */ var _tagbar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./tagbar */ "./lib/tagbar.js");
/* harmony import */ var _tagsmodel__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./tagsmodel */ "./lib/tagsmodel.js");
/* harmony import */ var _tokens__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./tokens */ "./lib/tokens.js");
/* harmony import */ var _icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./icon */ "./lib/icon.js");













const DEFAULT_TOOLBAR_ITEM_RANK = 50;
/**
 * Export the icons so they got loaded
 */

var CommandIDs;
(function (CommandIDs) {
    /**
     * Toggle cell attachments editor
     */
    CommandIDs.toggleAttachments = `${_tokens__WEBPACK_IMPORTED_MODULE_7__.EXTENSION_ID}:toggle-attachments`;
    /**
     * Toggle cell metadata editor
     */
    CommandIDs.toggleMetadata = `${_tokens__WEBPACK_IMPORTED_MODULE_7__.EXTENSION_ID}:toggle-metadata`;
    /**
     * Toggle cell toolbar
     */
    CommandIDs.toggleToolbar = `${_tokens__WEBPACK_IMPORTED_MODULE_7__.EXTENSION_ID}:toggle-toolbar`;
    /**
     * Toggle cell Raw NBConvert format
     */
    CommandIDs.toggleRawFormat = `${_tokens__WEBPACK_IMPORTED_MODULE_7__.EXTENSION_ID}:toggle-raw-format`;
    /**
     * Toggle cell slide type
     */
    CommandIDs.toggleSlideType = `${_tokens__WEBPACK_IMPORTED_MODULE_7__.EXTENSION_ID}:toggle-slide-type`;
    /**
     * Toggle cell tags
     */
    CommandIDs.toggleTags = `${_tokens__WEBPACK_IMPORTED_MODULE_7__.EXTENSION_ID}:toggle-tags`;
})(CommandIDs || (CommandIDs = {}));
/**
 * JupyterLab enhanced cell toolbar plugin.
 */
const extension = {
    id: `${_tokens__WEBPACK_IMPORTED_MODULE_7__.EXTENSION_ID}:plugin`,
    autoStart: true,
    optional: [_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_3__.ISettingRegistry, _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_4__.ITranslator, _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_1__.IEditorServices],
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.INotebookTracker, _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.IToolbarWidgetRegistry],
    activate: async (app, notebookTracker, toolbarRegistry, settingRegistry, translator, editorServices) => {
        const trans = (translator !== null && translator !== void 0 ? translator : _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_4__.nullTranslator).load('cell-toolbar');
        // Register specific toolbar items
        toolbarRegistry.registerFactory(_tokens__WEBPACK_IMPORTED_MODULE_7__.FACTORY_NAME, _tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.TAGS, (cell) => {
            const model = new _tagsmodel__WEBPACK_IMPORTED_MODULE_8__.TagsModel(cell.model);
            const widget = new _tagbar__WEBPACK_IMPORTED_MODULE_9__.TagTool(model);
            widget.disposed.connect(() => {
                model.dispose();
            });
            return widget;
        });
        // Extract the list from nbconvert service as in @jupyterlab/notebook-extension
        app.serviceManager.nbconvert
            .getExportFormats()
            .then(response => {
            if (response) {
                const coreTrans = (translator !== null && translator !== void 0 ? translator : _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_4__.nullTranslator).load('jupyterlab');
                /**
                 * The excluded Cell Inspector Raw NbConvert Formats
                 * (returned from nbconvert's export list)
                 */
                const rawFormatExclude = [
                    'pdf',
                    'slides',
                    'script',
                    'notebook',
                    'custom' // Exclude this as the input is editable
                ];
                const optionValueArray = [
                    ['pdf', coreTrans.__('PDF')],
                    ['slides', coreTrans.__('Slides')],
                    ['script', coreTrans.__('Script')],
                    ['notebook', coreTrans.__('Notebook')]
                ];
                // convert exportList to palette and menu items
                const formatList = Object.keys(response);
                formatList.forEach(key => {
                    if (rawFormatExclude.indexOf(key) === -1) {
                        const altOption = coreTrans.__(key[0].toUpperCase() + key.slice(1));
                        const coreLabel = coreTrans.__(key);
                        const option = coreLabel === key ? altOption : coreLabel;
                        const mimeTypeValue = response[key].output_mimetype;
                        optionValueArray.push([mimeTypeValue, option]);
                    }
                });
                toolbarRegistry.registerFactory(_tokens__WEBPACK_IMPORTED_MODULE_7__.FACTORY_NAME, _tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.RAW_FORMAT, (cell) => {
                    if (cell.model.type === 'raw') {
                        const w = new _attributeeditor__WEBPACK_IMPORTED_MODULE_10__.AttributeEditor({
                            metadata: cell.model.metadata,
                            keys: ['raw_mimetype', 'format'],
                            label: trans.__('Raw NBConvert Format'),
                            values: optionValueArray,
                            editable: true,
                            placeholder: trans.__('Click or press 🠗 for suggestions.'),
                            noValue: ''
                        });
                        w.addClass('jp-enh-cell-raw-format');
                        return w;
                    }
                    else {
                        const widget = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__.Widget();
                        widget.hide();
                        return widget;
                    }
                });
            }
            else {
                throw new Error('Fallback to default raw format.');
            }
        })
            .catch(() => {
            toolbarRegistry.registerFactory(_tokens__WEBPACK_IMPORTED_MODULE_7__.FACTORY_NAME, _tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.RAW_FORMAT, (cell) => {
                if (cell.model.type === 'raw') {
                    const w = new _attributeeditor__WEBPACK_IMPORTED_MODULE_10__.AttributeEditor({
                        metadata: cell.model.metadata,
                        keys: ['raw_mimetype', 'format'],
                        label: trans.__('Raw NBConvert Format'),
                        values: [
                            ['text/latex', 'LaTeX'],
                            ['text/restructuredtext', 'ReStructured Text'],
                            ['text/html', 'HTML'],
                            ['text/markdown', 'Markdown'],
                            ['text/x-python', 'Python']
                        ],
                        editable: true,
                        placeholder: trans.__('Click or press 🠗 for suggestions.'),
                        noValue: ''
                    });
                    w.addClass('jp-enh-cell-raw-format');
                    return w;
                }
                else {
                    const widget = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__.Widget();
                    widget.hide();
                    return widget;
                }
            });
        });
        toolbarRegistry.registerFactory(_tokens__WEBPACK_IMPORTED_MODULE_7__.FACTORY_NAME, _tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.SLIDESHOW, (cell) => {
            const w = new _attributeeditor__WEBPACK_IMPORTED_MODULE_10__.AttributeEditor({
                metadata: cell.model.metadata,
                keys: ['slideshow/slide_type'],
                label: trans.__('Slide Type'),
                values: [
                    ['slide', trans.__('Slide')],
                    ['subslide', trans.__('Sub-Slide')],
                    ['fragment', trans.__('Fragment')],
                    ['skip', trans.__('Skip')],
                    ['notes', trans.__('Notes')]
                ],
                noValue: '-'
            });
            w.addClass('jp-enh-cell-slide-type');
            return w;
        });
        toolbarRegistry.registerFactory(_tokens__WEBPACK_IMPORTED_MODULE_7__.FACTORY_NAME, _tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.ATTACHMENTS, (cell) => {
            var _a;
            if (['markdown', 'raw'].includes((_a = cell.model) === null || _a === void 0 ? void 0 : _a.type)) {
                return new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ToolbarButton({
                    label: trans.__('Edit Attachments…'),
                    actualOnClick: true,
                    onClick: async () => {
                        await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showDialog)({
                            title: trans.__('Edit Cell Attachments'),
                            body: new _attachmentseditor__WEBPACK_IMPORTED_MODULE_11__.AttachmentsEditor(cell.model.attachments, translator !== null && translator !== void 0 ? translator : _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_4__.nullTranslator),
                            buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.okButton({ label: trans.__('Close') })]
                        });
                    }
                });
            }
            else {
                return new _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__.Widget();
            }
        });
        if (editorServices) {
            toolbarRegistry.registerFactory(_tokens__WEBPACK_IMPORTED_MODULE_7__.FACTORY_NAME, _tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.METADATA, (cell) => new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ToolbarButton({
                label: trans.__('Edit Metadata…'),
                actualOnClick: true,
                onClick: async () => {
                    const body = new _metadataeditor__WEBPACK_IMPORTED_MODULE_12__.CellMetadataEditor(cell.model.metadata, editorServices.factoryService.newInlineEditor, translator !== null && translator !== void 0 ? translator : _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_4__.nullTranslator);
                    body.addClass('jp-cell-enh-metadata-editor');
                    await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showDialog)({
                        title: trans.__('Edit Cell Metadata'),
                        body,
                        buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.okButton({ label: trans.__('Close') })]
                    });
                }
            }));
        }
        // Add the widget extension
        let notebookExtension;
        if (settingRegistry) {
            const cellToolbarFactory = (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.createToolbarFactory)(toolbarRegistry, settingRegistry, _tokens__WEBPACK_IMPORTED_MODULE_7__.FACTORY_NAME, extension.id, translator !== null && translator !== void 0 ? translator : _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_4__.nullTranslator);
            settingRegistry
                .load(extension.id)
                .then(async (settings) => {
                await upgradeSettings(settings);
                notebookExtension = new _celltoolbartracker__WEBPACK_IMPORTED_MODULE_13__.CellBarExtension(app.commands, cellToolbarFactory, toolbarRegistry, settings);
                app.docRegistry.addWidgetExtension('Notebook', notebookExtension);
            })
                .catch(reason => {
                console.error(`Failed to load settings for ${extension.id}.`, reason);
            });
        }
        else {
            notebookExtension = new _celltoolbartracker__WEBPACK_IMPORTED_MODULE_13__.CellBarExtension(app.commands, (c) => _celltoolbartracker__WEBPACK_IMPORTED_MODULE_13__.DEFAULT_TOOLBAR.filter(item => !item.cellType || item.cellType === c.model.type).map(item => {
                return {
                    name: item.name,
                    widget: toolbarRegistry.createWidget(_tokens__WEBPACK_IMPORTED_MODULE_7__.FACTORY_NAME, c, item)
                };
            }), toolbarRegistry, null);
            app.docRegistry.addWidgetExtension('Notebook', notebookExtension);
        }
        // Add commands
        app.commands.addCommand(CommandIDs.toggleAttachments, {
            label: trans.__('Show Attachments'),
            execute: () => {
                const nb = notebookTracker.currentWidget;
                if (nb && notebookExtension) {
                    const handler = notebookExtension.getToolbarsHandler(nb);
                    if (handler) {
                        handler.setViewState(_tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.ATTACHMENTS, !handler.getViewState(_tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.ATTACHMENTS));
                    }
                }
            },
            isToggled: () => {
                const nb = notebookTracker.currentWidget;
                if (nb && notebookExtension) {
                    const handler = notebookExtension.getToolbarsHandler(nb);
                    if (handler) {
                        return handler.getViewState(_tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.ATTACHMENTS);
                    }
                }
                return false;
            }
        });
        app.commands.addCommand(CommandIDs.toggleMetadata, {
            label: trans.__('Show Metadata'),
            execute: () => {
                const nb = notebookTracker.currentWidget;
                if (nb && notebookExtension) {
                    const handler = notebookExtension.getToolbarsHandler(nb);
                    if (handler) {
                        handler.setViewState(_tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.METADATA, !handler.getViewState(_tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.METADATA));
                    }
                }
            },
            isToggled: () => {
                const nb = notebookTracker.currentWidget;
                if (nb && notebookExtension) {
                    const handler = notebookExtension.getToolbarsHandler(nb);
                    if (handler) {
                        return handler.getViewState(_tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.METADATA);
                    }
                }
                return false;
            }
        });
        app.commands.addCommand(CommandIDs.toggleRawFormat, {
            label: trans.__('Show Raw Cell Format'),
            execute: () => {
                const nb = notebookTracker.currentWidget;
                if (nb && notebookExtension) {
                    const handler = notebookExtension.getToolbarsHandler(nb);
                    if (handler) {
                        handler.setViewState(_tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.RAW_FORMAT, !handler.getViewState(_tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.RAW_FORMAT));
                    }
                }
            },
            isToggled: () => {
                const nb = notebookTracker.currentWidget;
                if (nb && notebookExtension) {
                    const handler = notebookExtension.getToolbarsHandler(nb);
                    if (handler) {
                        return handler.getViewState(_tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.RAW_FORMAT);
                    }
                }
                return false;
            }
        });
        app.commands.addCommand(CommandIDs.toggleSlideType, {
            label: trans.__('Show Slideshow'),
            execute: () => {
                const nb = notebookTracker.currentWidget;
                if (nb && notebookExtension) {
                    const handler = notebookExtension.getToolbarsHandler(nb);
                    if (handler) {
                        handler.setViewState(_tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.SLIDESHOW, !handler.getViewState(_tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.SLIDESHOW));
                    }
                }
            },
            isToggled: () => {
                const nb = notebookTracker.currentWidget;
                if (nb && notebookExtension) {
                    const handler = notebookExtension.getToolbarsHandler(nb);
                    if (handler) {
                        return handler.getViewState(_tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.SLIDESHOW);
                    }
                }
                return false;
            }
        });
        app.commands.addCommand(CommandIDs.toggleTags, {
            label: trans.__('Show Tags'),
            execute: () => {
                const nb = notebookTracker.currentWidget;
                if (nb && notebookExtension) {
                    const handler = notebookExtension.getToolbarsHandler(nb);
                    if (handler) {
                        handler.setViewState(_tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.TAGS, !handler.getViewState(_tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.TAGS));
                    }
                }
            },
            isToggled: () => {
                const nb = notebookTracker.currentWidget;
                if (nb && notebookExtension) {
                    const handler = notebookExtension.getToolbarsHandler(nb);
                    if (handler) {
                        return handler.getViewState(_tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.TAGS);
                    }
                }
                return false;
            }
        });
        app.commands.addCommand(CommandIDs.toggleToolbar, {
            label: trans.__('Show Toolbar'),
            execute: () => {
                const nb = notebookTracker.currentWidget;
                if (nb && notebookExtension) {
                    const handler = notebookExtension.getToolbarsHandler(nb);
                    if (handler) {
                        handler.isActive = !handler.isActive;
                    }
                }
            },
            isToggled: () => {
                const nb = notebookTracker.currentWidget;
                if (nb && notebookExtension) {
                    const handler = notebookExtension.getToolbarsHandler(nb);
                    if (handler) {
                        return handler.isActive;
                    }
                }
                return false;
            }
        });
        /**
         * Upgrade the settings from the old format of v3
         * @param settings Extension settings
         */
        async function upgradeSettings(settings) {
            const iconsMapping = {
                '@jlab-enhanced/cell-toolbar:code': 'ui-components:code',
                '@jlab-enhanced/cell-toolbar:delete': 'ui-components:delete'
            };
            const current = settings.composite;
            let wasUpgraded = false;
            const toolbarDefinition = [];
            let rank = 0;
            if (current['leftMenu']) {
                wasUpgraded = true;
                current['leftMenu'].forEach(item => {
                    var _a;
                    if (app.commands.hasCommand(item.command)) {
                        toolbarDefinition.push({
                            name: [item.command.split(':')[1], item.cellType].join('-'),
                            command: item.command,
                            icon: (_a = iconsMapping[item.icon]) !== null && _a !== void 0 ? _a : item.icon,
                            rank: rank++
                        });
                    }
                });
                await settings.remove('leftMenu');
            }
            rank = Math.max(rank, DEFAULT_TOOLBAR_ITEM_RANK);
            toolbarDefinition.push({ name: 'spacer', type: 'spacer', rank });
            if (current['showTags']) {
                wasUpgraded = true;
                toolbarDefinition.push({
                    name: _tokens__WEBPACK_IMPORTED_MODULE_7__.CellToolbar.ViewItems.TAGS,
                    rank: rank++
                });
                await settings.remove('showTags');
            }
            if (current['rightMenu']) {
                wasUpgraded = true;
                current['rightMenu'].forEach(item => {
                    var _a;
                    if (app.commands.hasCommand(item.command)) {
                        toolbarDefinition.push({
                            name: [item.command.split(':')[1], item.cellType].join('-'),
                            command: item.command,
                            icon: (_a = iconsMapping[item.icon]) !== null && _a !== void 0 ? _a : item.icon,
                            rank: rank++
                        });
                    }
                });
                await settings.remove('rightMenu');
            }
            if (wasUpgraded) {
                // Disabled default toolbar items
                const names = toolbarDefinition.map(t => t.name);
                for (const item of _celltoolbartracker__WEBPACK_IMPORTED_MODULE_13__.DEFAULT_TOOLBAR) {
                    if (!names.includes(item.name)) {
                        toolbarDefinition.push({ name: item.name, disabled: true });
                    }
                }
                await settings.set('toolbar', toolbarDefinition);
                await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showDialog)({
                    title: 'Information',
                    body: trans.__('The toolbar extension has been upgraded. You need to refresh the web page to take into account the new configuration.')
                });
            }
        }
    }
};
/**
 * Notebook tools plugin
 */
const nbTools = {
    id: `${_tokens__WEBPACK_IMPORTED_MODULE_7__.EXTENSION_ID}:tools`,
    autoStart: true,
    activate: async (app, notebookTools, translator) => {
        notebookTools.addItem({
            tool: new _attachmentseditor__WEBPACK_IMPORTED_MODULE_11__.AttachmentsTool(translator !== null && translator !== void 0 ? translator : _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_4__.nullTranslator),
            section: 'common'
        });
    },
    optional: [_jupyterlab_translation__WEBPACK_IMPORTED_MODULE_4__.ITranslator],
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.INotebookTools]
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ([extension, nbTools]);


/***/ }),

/***/ "./lib/metadataeditor.js":
/*!*******************************!*\
  !*** ./lib/metadataeditor.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CellMetadataEditor": () => (/* binding */ CellMetadataEditor)
/* harmony export */ });
/* harmony import */ var _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/codeeditor */ "webpack/sharing/consume/default/@jupyterlab/codeeditor");
/* harmony import */ var _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/translation */ "webpack/sharing/consume/default/@jupyterlab/translation");
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_translation__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_2__);



class CellMetadataEditor extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.Widget {
    constructor(metadata, editorFactory, translator) {
        super();
        const trans = (translator !== null && translator !== void 0 ? translator : _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_1__.nullTranslator).load('cell-toolbar');
        const layout = (this.layout = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.PanelLayout());
        const editor = new _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_0__.JSONEditor({ editorFactory, translator });
        editor.source = metadata;
        const node = document.createElement('p');
        node.innerText = trans.__("Manually edit the JSON below to manipulate the metadata for this cell. We recommend putting custom metadata attributes in an appropriately named substructure, so they don't conflict with those of others.");
        layout.addWidget(new _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.Widget({ node }));
        layout.addWidget(editor);
    }
}


/***/ }),

/***/ "./lib/positionedbutton.js":
/*!*********************************!*\
  !*** ./lib/positionedbutton.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PositionedButton": () => (/* binding */ PositionedButton)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Positioned helper button
 */
class PositionedButton extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__.Widget {
    constructor(item) {
        super({ node: Private.createNode(item) });
        this.addClass('jp-enh-cell-button');
        this._callback = item.callback;
    }
    /**
     * Handle the DOM events for the tab bar.
     *
     * @param event - The DOM event sent to the tab bar.
     *
     * #### Notes
     * This method implements the DOM `EventListener` interface and is
     * called in response to events on the tab bar's DOM node.
     *
     * This should not be called directly by user code.
     */
    handleEvent(event) {
        switch (event.type) {
            case 'mousedown':
                this._evtMouseDown(event);
                break;
        }
    }
    /**
     * A message handler invoked on a `'before-attach'` message.
     */
    onBeforeAttach(msg) {
        this.node.addEventListener('mousedown', this);
    }
    /**
     * A message handler invoked on an `'after-detach'` message.
     */
    onAfterDetach(msg) {
        this.node.removeEventListener('mousedown', this);
    }
    /**
     * Handle the `'mousedown'` event for the tab bar.
     */
    _evtMouseDown(event) {
        // Do nothing if it's not a left or middle mouse press.
        if (event.button !== 0) {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        this._callback();
    }
}
var Private;
(function (Private) {
    // eslint-disable-next-line no-inner-declarations
    function createNode(item) {
        const button = document.createElement('button');
        if (item.tooltip) {
            button.title = item.tooltip;
        }
        if (item.className) {
            button.classList.add(item.className);
        }
        _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon.resolve({ icon: item.icon }).element({
            container: button,
            elementPosition: 'center',
            elementSize: 'normal'
        });
        return button;
    }
    Private.createNode = createNode;
})(Private || (Private = {}));


/***/ }),

/***/ "./lib/tagbar.js":
/*!***********************!*\
  !*** ./lib/tagbar.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TagTool": () => (/* binding */ TagTool)
/* harmony export */ });
/* harmony import */ var _jupyterlab_celltags__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/celltags */ "webpack/sharing/consume/default/@jupyterlab/celltags");
/* harmony import */ var _jupyterlab_celltags__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_celltags__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/algorithm */ "webpack/sharing/consume/default/@lumino/algorithm");
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_algorithm__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_2__);



const CELL_TAGS_CLASS = 'jp-enh-cell-tags';
const CELL_CLICKABLE_TAG_CLASS = 'jp-enh-cell-mod-click';
/**
 * A container for cell tags.
 */
class TagTool extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.Widget {
    /**
     * Construct a new tag Tool.
     */
    constructor(model) {
        super();
        this._model = model;
        this.layout = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.PanelLayout();
        this.addClass(CELL_TAGS_CLASS);
        this._createTagInput();
        this.onTagsModelChanged();
        this._model.stateChanged.connect(this.onTagsModelChanged, this);
    }
    get model() {
        return this._model;
    }
    dispose() {
        if (this.isDisposed) {
            return;
        }
        this._model.stateChanged.disconnect(this.onTagsModelChanged, this);
        super.dispose();
    }
    // addTag, checkApplied and removeTag are needed because the core widget
    // call those methods on their parent widget :-/
    /**
     * Check whether a tag is applied to the current active cell
     *
     * @param name - The name of the tag.
     *
     * @returns A boolean representing whether it is applied.
     */
    checkApplied(name) {
        return this._model.checkApplied(name);
    }
    /**
     * Add a tag to the current active cell.
     *
     * @param name - The name of the tag.
     */
    addTag(name) {
        if (!this._model.unlockedTags) {
            // Style toggling is applied on the widget directly => force rerendering
            this._refreshOneTag(name);
        }
        this._model.addTag(name);
    }
    /**
     * Remove a tag from the current active cell.
     *
     * @param name - The name of the tag.
     */
    removeTag(name) {
        if (!this._model.unlockedTags) {
            // Style toggling is applied on the widget directly => force rerendering
            this._refreshOneTag(name);
            return;
        }
        this._model.removeTag(name);
    }
    /**
     * Update the tag widgets for the current cell.
     */
    refreshTags() {
        const layout = this.layout;
        const tags = [...new Set((0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_1__.toArray)(this._model.tags))];
        const allTags = [...tags].sort((a, b) => (a > b ? 1 : -1));
        // Dispose removed tags
        const toDispose = new Array();
        layout.widgets.forEach(widget => {
            if (widget.id !== 'add-tag') {
                const idx = tags.indexOf(widget.name);
                if (idx < 0) {
                    toDispose.push(widget);
                }
                else {
                    tags.splice(idx, 1);
                }
            }
        });
        toDispose.forEach(widget => widget.dispose());
        // Insert new tags
        tags.forEach(tag => {
            layout.insertWidget(this.layout.widgets.length - 1, new _jupyterlab_celltags__WEBPACK_IMPORTED_MODULE_0__.TagWidget(tag));
        });
        // Sort the widgets in tag alphabetical order
        [...layout.widgets].forEach((widget, index) => {
            let tagIndex = allTags.findIndex(tag => widget.name === tag);
            // Handle AddTag widget case
            if (tagIndex === -1) {
                tagIndex = allTags.length;
            }
            if (tagIndex !== index) {
                layout.insertWidget(tagIndex, widget);
            }
        });
        // Update all tags widgets
        layout.widgets.forEach(widget => {
            widget.update();
            if (this._model.unlockedTags) {
                widget.show();
                widget.addClass(CELL_CLICKABLE_TAG_CLASS);
            }
            else {
                if (widget.id === 'add-tag' ||
                    !this._model.checkApplied(widget.name)) {
                    widget.hide();
                }
                else {
                    widget.show();
                    widget.removeClass(CELL_CLICKABLE_TAG_CLASS);
                }
            }
        });
    }
    /**
     * Add an AddWidget input box to the layout.
     */
    _createTagInput() {
        const layout = this.layout;
        const input = new _jupyterlab_celltags__WEBPACK_IMPORTED_MODULE_0__.AddWidget();
        input.id = 'add-tag';
        layout.addWidget(input);
    }
    /**
     * Force refreshing one tag widget
     *
     * @param name Tag
     */
    _refreshOneTag(name) {
        var _a;
        (_a = [...this.layout.widgets]
            .find(widget => widget.id !== 'add-tag' && widget.name === name)) === null || _a === void 0 ? void 0 : _a.update();
    }
    /**
     * Listener on shared tag list changes
     */
    onTagsModelChanged() {
        this.refreshTags();
    }
}


/***/ }),

/***/ "./lib/tagsmodel.js":
/*!**************************!*\
  !*** ./lib/tagsmodel.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TagsModel": () => (/* binding */ TagsModel)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_observables__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/observables */ "webpack/sharing/consume/default/@jupyterlab/observables");
/* harmony import */ var _jupyterlab_observables__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_observables__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Model handling tag lists
 *
 * stateChanged signal is emitted when the tags list or the
 * unlockedTags attributes changes.
 */
class TagsModel extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.VDomModel {
    /**
     * Constructor
     *
     * @param model Cell model
     * @param tagsList Notebook tag list
     * @param unlockedTags Whether the tags are read-only or not
     */
    constructor(model, tagsList, unlockedTags = true) {
        super();
        this._model = model;
        this._tags = tagsList !== null && tagsList !== void 0 ? tagsList : new _jupyterlab_observables__WEBPACK_IMPORTED_MODULE_1__.ObservableList();
        this._unlockedTags = unlockedTags;
        // Update tag list
        const tags = this._model.metadata.get('tags') || [];
        if (tags.length > 0) {
            this._tags.pushAll(tags);
        }
        model.metadata.changed.connect(this.onCellMetadataChanged, this);
        this._tags.changed.connect(this._emitStateChange, this);
    }
    /**
     * Notebook tags list
     */
    get tags() {
        return this._tags;
    }
    set tags(l) {
        if (l !== this._tags) {
            this._tags = l;
            // Update tag list
            const tags = this._model.metadata.get('tags') || [];
            if (tags.length > 0) {
                this._tags.pushAll(tags);
            }
            this.stateChanged.emit();
        }
    }
    /**
     * Whether the tags are read-only or not
     */
    get unlockedTags() {
        return this._unlockedTags;
    }
    set unlockedTags(v) {
        if (v !== this._unlockedTags) {
            this._unlockedTags = v;
            this.stateChanged.emit();
        }
    }
    /**
     * Add a tag to the current active cell.
     *
     * @param name - The name of the tag.
     */
    addTag(name) {
        const tags = this._model.metadata.get('tags') || [];
        const newTags = name
            .split(/[,\s]+/)
            .filter(tag => tag !== '' && !tags.includes(tag));
        // Update the cell metadata => tagList will be updated in metadata listener
        this._model.metadata.set('tags', [...tags, ...newTags]);
    }
    /**
     * Check whether a tag is applied to the current active cell
     *
     * @param name - The name of the tag.
     *
     * @returns A boolean representing whether it is applied.
     */
    checkApplied(name) {
        const tags = this._model.metadata.get('tags') || [];
        return tags.some(tag => tag === name);
    }
    /**
     * Dispose the model.
     */
    dispose() {
        if (this.isDisposed) {
            return;
        }
        this._model.metadata.changed.disconnect(this.onCellMetadataChanged, this);
        this._tags.changed.disconnect(this._emitStateChange, this);
        super.dispose();
    }
    /**
     * Remove a tag from the current active cell.
     *
     * @param name - The name of the tag.
     */
    removeTag(name) {
        // Need to copy as we splice a mutable otherwise
        const tags = [...(this._model.metadata.get('tags') || [])];
        const idx = tags.indexOf(name);
        if (idx > -1) {
            tags.splice(idx, 1);
        }
        // Update the cell metadata => tagList will be update in metadata listener
        if (tags.length === 0) {
            this._model.metadata.delete('tags');
        }
        else {
            this._model.metadata.set('tags', tags);
        }
    }
    /**
     * Propagate the cell metadata changes to the shared tag list.
     *
     * @param metadata Cell metadata
     * @param changes Metadata changes
     */
    onCellMetadataChanged(metadata, changes) {
        if (changes.key === 'tags') {
            const oldTags = [...new Set(changes.oldValue || [])];
            const newTags = this._validateTags(changes.newValue || []);
            oldTags.forEach(tag => {
                if (!newTags.includes(tag)) {
                    this.tags.removeValue(tag);
                }
            });
            this.tags.pushAll(newTags.filter(tag => !oldTags.includes(tag)));
        }
    }
    /**
     * Validate the 'tags' of cell metadata, ensuring it is a list of strings and
     * that each string doesn't include spaces.
     *
     * @param tagList Tags array to be validated
     * @returns Validated tags array
     */
    _validateTags(tagList) {
        const results = new Set();
        tagList
            .filter(tag => typeof tag === 'string' && tag !== '')
            .forEach(tag => {
            tag.split(/[,\s]+/).forEach(subTag => {
                if (subTag !== '') {
                    results.add(subTag);
                }
            });
        });
        return [...results];
    }
    _emitStateChange() {
        this.stateChanged.emit();
    }
}


/***/ }),

/***/ "./lib/tokens.js":
/*!***********************!*\
  !*** ./lib/tokens.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CellToolbar": () => (/* binding */ CellToolbar),
/* harmony export */   "EXTENSION_ID": () => (/* binding */ EXTENSION_ID),
/* harmony export */   "FACTORY_NAME": () => (/* binding */ FACTORY_NAME)
/* harmony export */ });
const EXTENSION_ID = '@jlab-enhanced/cell-toolbar';
const FACTORY_NAME = 'Cell';
var CellToolbar;
(function (CellToolbar) {
    /**
     * View toggleable items
     */
    let ViewItems;
    (function (ViewItems) {
        /**
         * Attachments toolbar item name
         */
        ViewItems["ATTACHMENTS"] = "attachments";
        /**
         * Metadata toolbar item name
         */
        ViewItems["METADATA"] = "metadata";
        /**
         * Raw format toolbar item name
         */
        ViewItems["RAW_FORMAT"] = "raw-format";
        /**
         * Slide type toolbar item name
         */
        ViewItems["SLIDESHOW"] = "slide-type";
        /**
         * Tags toolbar item name
         */
        ViewItems["TAGS"] = "tags";
    })(ViewItems = CellToolbar.ViewItems || (CellToolbar.ViewItems = {}));
})(CellToolbar || (CellToolbar = {}));


/***/ }),

/***/ "./lib/utils.js":
/*!**********************!*\
  !*** ./lib/utils.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getCSSVar": () => (/* binding */ getCSSVar)
/* harmony export */ });
/**
 * Get the value of a CSS variable
 *
 * @param name CSS variable name
 * @returns The CSS variable value
 */
function getCSSVar(name) {
    return getComputedStyle(document.documentElement)
        .getPropertyValue(name)
        .trim();
}


/***/ }),

/***/ "./style/icons/format.svg":
/*!********************************!*\
  !*** ./style/icons/format.svg ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" focusable=\"false\" width=\"16px\"\n    height=\"16px\" style=\"-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);\"\n    preserveAspectRatio=\"xMidYMid meet\" viewBox=\"0 0 1792 1792\">\n    <path class=\"jp-icon3\"\n        d=\"M1473 929q7-118-33-226.5t-113-189t-177-131T929 325q-116-7-225.5 32t-192 110.5t-135 175T317 863q-7 118 33 226.5t113 189t177.5 131T862 1467q155 9 293-59t224-195.5t94-283.5zM1792 0l-349 348q120 117 180.5 272t50.5 321q-11 183-102 339t-241 255.5T999 1660L0 1792l347-347q-120-116-180.5-271.5T116 852q11-184 102-340t241.5-255.5T792 132q167-22 500-66t500-66z\"\n        fill=\"#626262\" />\n</svg>");

/***/ }),

/***/ "./style/icons/lockedtags.svg":
/*!************************************!*\
  !*** ./style/icons/lockedtags.svg ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" width=\"16\" height=\"16\">\n    <path d=\"M0 0h24v24H0z\" fill=\"none\" />\n    <path class=\"jp-icon3\"\n        d=\"M9.406 6.862h5.265c1.12-.07 2.047.117 2.632.702 0 0 3.532 2.633 5.265 4.476-1.745 1.793-2.623 2.35-4.387 4.124m-.176 2.457c-.196.193-1.524 1.571-1.755 1.755l-2.983-2.983H3.263c-2.005 0-1.731-.003-1.755-1.755v-7.02c-.025-1.722.059-1.726 2.633-1.756L.98 3.704l1.931-1.579z\"\n        fill=\"#626262\" />\n</svg>");

/***/ }),

/***/ "./style/icons/unlockedtags.svg":
/*!**************************************!*\
  !*** ./style/icons/unlockedtags.svg ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" width=\"16\" height=\"16\">\n    <path d=\"M0 0h24v24H0z\" fill=\"none\" />\n    <path class=\"jp-icon3\"\n        d=\"M14.636 17.27H3.23c-1.772-.06-1.791-.09-1.755-1.756v-7.02c-.026-1.72.001-1.755 1.755-1.755h11.407c1.121-.07 2.048.293 2.633.878 0 0 3.532 2.457 5.265 4.3-1.746 1.793-3.206 2.868-5.265 4.475-.585.585-1.631.887-2.633.877z\"\n        fill=\"#626262\" />\n</svg>");

/***/ })

}]);
//# sourceMappingURL=lib_index_js.0f53c15d8bb628f3c503.js.map